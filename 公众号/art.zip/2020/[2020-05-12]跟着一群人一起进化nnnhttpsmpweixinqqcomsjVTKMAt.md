![](http://mmbiz.qpic.cn/mmbiz_png/tOFSAibJ5wquD6oOjlfvPKmvHuvhvuNiciapByofaxOp25SWAY2lK7YNppYHdu7VuGuGiadDAVibF9zWjIroAVITelg/300?wx_fmt=png)

星佳是个小人物

跟着一群人，一起进化

https://mp.weixin.qq.com/s/jVTKMAt4DiVM1oIFfPLdMg

跟着一群人，一起进化

https://mp.weixin.qq.com/s/jVTKMAt4DiVM1oIFfPLdMg

,

,

跟着一群人，一起进化\x0a\x0a\x0ahttps://mp.weixin.qq.com/s/jVTKMAt4DiVM1oIFfPLdMg

![](https://mmbiz.qpic.cn/mmbiz_jpg/tOFSAibJ5wqv13hia317VaH2h6oKWXRuCwic0MTuD5Ecichyjjr4KmSFBLbAnqaW0nvbOYdgDHWKykIgTibmedrEyMA/0?wx_fmt=jpeg)![]()![]()![](https://mmbiz.qpic.cn/mmbiz_jpg/tOFSAibJ5wqv13hia317VaH2h6oKWXRuCwb5TJEYXTwdN25nbVdEeIMVv88rD0ic9lUgXGxUnvWSJEvI80mXIIRMw/0?wx_fmt=jpeg)![]()![]()![](https://mmbiz.qpic.cn/mmbiz_jpg/tOFSAibJ5wqv13hia317VaH2h6oKWXRuCwS6r9nq5LC4Tpl54rTWoDTGpJEVQyG5jFxlvLx6A0RBul9vDAaLxfZg/0?wx_fmt=jpeg)![]()![]()
,

[ 知道了 ](javascript:;)

微信扫一扫  
使用小程序

****

[ 取消 ](javascript:void\(0\);) [ 允许 ](javascript:void\(0\);)

****



****





__











![](http://wx.qlogo.cn/mmopen/ajNVdqHZLLCz7mZyTFaXCXKYrCyJSibLjxGoBsy62TibznLu1zm1b7aBCncMkkznEgHQbVks4QDFgXwPHfcHhnuw/64)

顺康雍乾来自

总结的非常好

![](http://wx.qlogo.cn/mmhead/Q3auHgzwzM7ibr9SQjIH7381Xz5TLIvx3OGbiaR4bib18niaVc7t4T9pGA/64)

星佳是个小人物来自

等 woody 之后的复盘文章，同时期待职场老司机揭秘更多职场潜规则啦

